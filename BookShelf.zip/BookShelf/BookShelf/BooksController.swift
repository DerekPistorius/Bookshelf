//
//  BooksController.swift
//  BookShelf
//
//  Created by Derek Pistorius on 4/18/22.
//
//Need 6 books

import Foundation


class BookController {
    
    static var books: [Book] {
        
        let mambaMentality = Book(title: "The Mamba Mentality: How I Play", author: "Andrew D. Bernstein", coverImage: "mambaMentalityCover", releaseYear: "October 23rd, 2018", description: "In the wake of his retirement from professional basketball, Kobe “The Black Mamba” Bryant decided to share his vast knowledge and understanding of the game to take readers on an unprecedented journey to the core of the legendary “Mamba mentality.” Citing an obligation and an opportunity to teach young players, hardcore fans, and devoted students of the game how to play it “the right way,” The Mamba Mentality takes us inside the mind of one of the most intelligent, analytical, and creative basketball players ever.")
        
        let theDaVinciCode = Book(title: "The Davinci Code", author: "Dan Brown", coverImage: "theDavinciCodeCover", releaseYear: "April 1st, 2003", description: "The Da Vinci Code is a 2003 mystery thriller novel by Dan Brown. It is Brown's second novel to include the character Robert Langdon: the first was his 2000 novel Angels & Demons. The Da Vinci Code follows symbologist Robert Langdon and cryptologist Sophie Neveu after a murder in the Louvre Museum in Paris causes them to become involved in a battle between the Priory of Sion and Opus Dei over the possibility of Jesus Christ and Mary Magdalene having had a child together.")
        
        let michaelJordanTheLife = Book(title: "Michael Jordan: The Life", author: "Roland Lazenby", coverImage: "michaelJordanTheLifeCover", releaseYear: "May 6th, 2014", description: "The Shrug. The Shot. The Flu Game. Michael Jordan is responsible for sublime moments so ingrained in sports history that they have their own names. When most people think of him, they think of his beautiful shots with the game on the line, his body totally in sync with the ball -- hitting nothing but net.")
        
        let fiftyShadesOfGrey = Book(title: "Fifty Shades Of Grey", author: "E. L. James", coverImage: "fiftyShadesOfGreyCover", releaseYear: "June 20th, 2011", description: "Fifty Shades of Grey is a 2011 erotic romance novel by British author E. L. James. It became the first instalment in the Fifty Shades novel series that follows the deepening relationship between a college graduate, Anastasia Steele, and a young business magnate, Christian Grey. It is notable for its explicitly erotic scenes featuring elements of sexual practices involving BDSM (bondage/discipline, dominance/submission, and sadism/masochism). Originally self-published as an ebook and print-on-demand in June 2011, the publishing rights to the novel were acquired by Vintage Books in March 2012.")
        
        let theOrangeBird = Book(title: "The Orange Bird", author: "Jason Grandt", coverImage: "theOrangeBirdCover", releaseYear: "January 18th, 2022", description: "With its orange head, leaf wings, and bird body, Orange Bird is a true Disney original! Get to know this sweet, fun-loving bird in this all-new Little Golden Book, perfect for children ages 2 to 5, Disney Parks fans, and collectors of all ages!")
        
        let thePowerOfMoments = Book(title: "The Power Of Moments", author: "Dan Heath & Chip Heath", coverImage: "thePowerOfMomentsCover", releaseYear: "October 13, 2017", description: "The Power of Moments is about why certain brief experiences can jolt us and elevate us and change us—and how we can learn to create such extraordinary moments in our life and work.")
        
        return [mambaMentality, theDaVinciCode, michaelJordanTheLife, fiftyShadesOfGrey, theOrangeBird, thePowerOfMoments]
        
        
    }

}
