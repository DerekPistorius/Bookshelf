//
//  bookTableViewCell.swift
//  BookShelf
//
//  Created by Derek Pistorius on 4/18/22.
//

import UIKit


class bookTableViewCell: UITableViewCell {
    
    var book: Book?
    
    override func updateConfiguration(using state: UICellConfigurationState) {
        super.updateConfiguration(using: state)
        
        var content = defaultContentConfiguration().updated(for: state)
        var backgroundContent = backgroundConfiguration?.updated(for: state)



    guard let book = book else { return }//dbl check this line
    
content.text = book.title // check this line
    content.secondaryText = "Release Year: \(book.releaseYear)" //check this line
    content.image = UIImage(named: book.coverImage)
    content.imageProperties.maximumSize = CGSize(width: 100, height: 100) //to resize pics
    backgroundContent?.backgroundColor = .clear
    
    if state.isHighlighted || state.isSelected {
        backgroundContent?.backgroundColor = .systemMint
                content.textProperties.color = .black
                //this one isn't doing anything bc its not a system image
                content.imageProperties.tintColor = .red
            }
    contentConfiguration = content
    backgroundConfiguration = backgroundContent

            
    }

}
