//
//  BookViewController.swift
//  BookShelf
//
//  Created by Derek Pistorius on 4/19/22.
//

import UIKit

class BookViewController: UIViewController {
    
    
    @IBOutlet weak var image: UIImageView!
    
    @IBOutlet weak var bookDetailLabel: UILabel!
    
    
    @IBOutlet weak var label: UILabel!
    
    
    
    var book: Book?
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        updateView()
        

    }
    
    func updateView() {
        guard let book = book else {
            return
        }

    
    
    
    label.text = book.title
    image.image = UIImage(named: book.coverImage)
    bookDetailLabel.text = "Author: \(book.author)Releasse Year: \(book.releaseYear)Description: \(book.description)"

    }
    

}
