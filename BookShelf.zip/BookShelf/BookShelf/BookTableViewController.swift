//
//  BookTableViewController.swift
//  BookShelf
//
//  Created by Derek Pistorius on 4/18/22.
//

import UIKit

class BookTableViewController: UITableViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return BookController.books.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "bookCell", for: indexPath) as? bookTableViewCell else { return UITableViewCell()}


        // Havent created bookTableViewCell yet. Once I do this error should go away

        let book = BookController.books[indexPath.row]
        cell.book = book
        return cell


        }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "segueToDetail" {
            guard let destinationVC = segue.destination as? BookViewController else { return }
            guard let cell = sender as? bookTableViewCell else { return }
            guard let indexPath = tableView.indexPath(for: cell) else { return }
            let book = BookController.books[indexPath.row]
            destinationVC.book = book
        }
 
        //research bookviewcontroller
        //another booktableviewcell, error should clear once created
    }
    
}


//need to make book view controller

