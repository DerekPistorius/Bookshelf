//
//  Books.swift
//  BookShelf
//
//  Created by Derek Pistorius on 4/18/22.
//
/*Make a class for books
 Should include 6 books
 Book details Need to include
    title, author, cover, release year, description
 */



import Foundation


class Book {
    
    let title: String
    let author: String
    let coverImage: String //Note this needs to be a picture
    let releaseYear: String
    let description: String
    
    init(title: String, author: String, coverImage: String, releaseYear: String, description: String) {
        
        self.title = title
        self.author = author
        self.coverImage = coverImage
        self.releaseYear = releaseYear
        self.description = description
        
    }
    
    
}
