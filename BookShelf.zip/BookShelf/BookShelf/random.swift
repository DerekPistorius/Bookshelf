//
//  random.swift
//  BookShelf
//
//  Created by Derek Pistorius on 4/19/22.
//

import UIKit



class Random: UITableViewController {
    let red = UIColor.red
    
    
    
}
